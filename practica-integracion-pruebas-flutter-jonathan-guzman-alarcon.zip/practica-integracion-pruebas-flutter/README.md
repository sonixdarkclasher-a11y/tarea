# Práctica de Integración y Pruebas en Flutter – Administrador de tareas

**Estudiante:** Jonathan Josué Guzmán Alarcón  
**Carné:** 2927732022

Este proyecto consiste en una aplicación móvil desarrollada con Flutter para organizar actividades. Permite registrar tareas, revisar el listado, modificar información, indicar cuáles ya se completaron y borrar registros. La información se almacena en Cloud Firestore.

## Requisitos
- Flutter SDK estable y Dart compatible con `pubspec.yaml`.
- Android Studio o VS Code.
- Proyecto Firebase con Cloud Firestore habilitado.
- Emulador o dispositivo Android.

## Configuración Firebase
1. Cree un proyecto en Firebase Console.
2. Registre la aplicación Android con el `applicationId` de su proyecto Flutter.
3. Configure FlutterFire CLI (`dart pub global activate flutterfire_cli` y `flutterfire configure`).
4. Ejecute `flutter pub get`.
5. Verifique que `Firebase.initializeApp()` tenga la configuración generada para su plataforma.
6. Cree la colección `tasks` o permita su creación al insertar el primer documento.
7. Configure reglas seguras antes de publicar. No use reglas abiertas en producción.

> No se incluye `google-services.json`, archivo de opciones Firebase ni credenciales. Cada integrante debe configurar su propio proyecto Firebase.

## Ejecución
```bash
flutter pub get
flutter run
```

## Validación
```bash
flutter analyze
flutter test
```

## Características principales
- Consulta de tareas con actualización en tiempo real.
- Registro de nuevas actividades y modificación de las existentes.
- Cambio del estado de una tarea entre pendiente y completada.
- Eliminación de elementos que ya no se necesitan.
- Comprobación del título: se solicita un mínimo de tres caracteres.
- Avisos para informar cuando ocurre un problema al guardar o consultar datos.

## Rama de trabajo sugerida
```bash
git checkout -b semana16-integracion
```

## Estado de evidencias
En la carpeta `docs/` se encuentra la documentación de la práctica y los formatos para registrar las pruebas. La imagen incluida es únicamente una guía de la apariencia esperada; debe acompañarse con capturas tomadas durante la ejecución. Antes de entregar, agregue los resultados obtenidos en `flutter analyze`, `flutter test`, Firebase Console y el emulador o teléfono utilizado.
