# 01. Alcance de la aplicación

**Estudiante:** Jonathan Josué Guzmán Alarcón  
**Carné:** 2927732022

**Proyecto:** Gestión de tareas  
**Servicio principal:** Cloud Firestore  
**Plataforma objetivo:** Android  
**Rama:** `semana16-integracion`

| Módulo / servicio | ¿Aplica? | Observación |
|---|---|---|
| Autenticación | No | La versión de esta práctica no incorpora cuentas de usuario. |
| Base de datos Firestore | Sí | Colección `tasks`; altas, lectura en tiempo real, actualización y eliminación. |
| Almacenamiento Storage | No | No se adjuntan imágenes ni archivos a las tareas. |
| Notificaciones FCM | No | No forma parte del alcance funcional de esta versión. |
| API REST externa | No | La persistencia se realiza directamente con Firestore. |
| Otros | No | No se integran Analytics, Crashlytics ni Remote Config. |

**Motivo de esta selección:** Para esta entrega se trabajará con Firestore como servicio de almacenamiento y consulta. Así, las verificaciones se enfocan en crear, mostrar, modificar y eliminar tareas, además de comprobar que la interfaz refleje los cambios. La aplicación no contempla inicio de sesión, carga de archivos ni avisos push; por eso, esos apartados se identifican como no aplicables y no se presentan como pruebas realizadas.
