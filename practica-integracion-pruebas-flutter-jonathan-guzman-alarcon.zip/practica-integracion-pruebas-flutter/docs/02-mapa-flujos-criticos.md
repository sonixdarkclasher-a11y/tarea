# 02. Recorrido de las funciones principales

**Estudiante:** Jonathan Josué Guzmán Alarcón  
**Carné:** 2927732022

1. Al iniciar la app, se presenta el listado de actividades disponibles.
2. Desde el botón de creación, se registra una nueva tarea indicando un título y, si se desea, una descripción.
3. Al tocar un elemento de la lista, se abre el formulario para actualizar su información.
4. Se puede cambiar una tarea a estado completado mediante su casilla de selección.
5. La opción de eliminar retira la actividad del listado y de la colección correspondiente.

**Escenario de validación:** si se intenta guardar sin escribir un título o se ingresan menos de tres caracteres, el formulario debe mostrar una indicación y cancelar el guardado.
