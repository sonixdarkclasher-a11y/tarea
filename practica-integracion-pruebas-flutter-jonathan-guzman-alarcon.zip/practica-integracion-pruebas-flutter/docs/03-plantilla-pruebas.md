# 03. Registro de casos de prueba

**Estudiante:** Jonathan Josué Guzmán Alarcón  
**Carné:** 2927732022

**Antes de cerrar la práctica:** anote en la última columna lo que realmente ocurrió, junto con la fecha, el dispositivo o emulador y el nombre de la evidencia. Un caso solo debe cambiarse a Aprobado cuando se haya ejecutado y exista una captura o registro que lo respalde.

| ID | Módulo | Descripción / entrada | Resultado esperado | Resultado obtenido / estado |
|---|---|---|---|---|
| CP-01 | Arranque | Abrir la app | Lista visible sin excepción | Pendiente de ejecución |
| CP-02 | Navegación | Pulsar Nueva tarea | Abre formulario | Pendiente de ejecución |
| CP-03 | Navegación | Volver desde formulario | Regresa a lista | Pendiente de ejecución |
| CP-04 | Validación | Guardar título vacío | Mensaje “Escribe un título”; sin escritura | Automatizado en test; repetir en dispositivo |
| CP-05 | Validación | Título “ab” | Mensaje de mínimo 3 caracteres | Automatizado en unit test; repetir en dispositivo |
| CP-06 | Datos | Crear “Comprar materiales” | Documento aparece en lista | Pendiente de ejecución con Firebase |
| CP-07 | Datos | Abrir y editar descripción | Cambio reflejado en lista y Firestore | Pendiente de ejecución con Firebase |
| CP-08 | Datos | Marcar checkbox | Estado completado actualizado | Pendiente de ejecución con Firebase |
| CP-09 | Datos | Eliminar tarea | Documento y elemento desaparecen | Pendiente de ejecución con Firebase |
| CP-10 | Persistencia | Cerrar y reabrir app | Tareas conservadas | Pendiente de ejecución con Firebase |
| CP-11 | Estados | Firestore sin documentos | Mensaje “No hay tareas todavía” | Pendiente de ejecución |
| CP-12 | Errores | Simular pérdida de conexión | Mensaje controlado, sin cierre | Pendiente de ejecución |

**Balance de esta plantilla:** se proponen doce escenarios para revisar el funcionamiento general. Todavía es necesario ejecutar los casos pendientes en un emulador o teléfono conectado al proyecto Firebase y completar sus resultados. Las pruebas automatizadas disponibles revisan la validación y el formulario con un repositorio simulado; no comprueban por sí solas la conexión real con Firestore.
