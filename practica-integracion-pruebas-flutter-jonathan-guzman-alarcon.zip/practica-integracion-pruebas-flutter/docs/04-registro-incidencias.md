# 04. Control de incidencias

**Estudiante:** Jonathan Josué Guzmán Alarcón  
**Carné:** 2927732022

Los casos de esta tabla son situaciones identificadas como referencia para documentar la depuración. Es necesario comprobar cada una en el entorno de trabajo, confirmar su comportamiento y agregar evidencia antes de describirla como un problema reproducido.

| ID | Severidad / prioridad | Origen | Descripción y causa | Corrección propuesta | Estado |
|---|---|---|---|---|---|
| INC-001 | Alta / P1 | Validación UI | El formulario podría aceptar un título vacío si no se ejecuta la validación antes de guardar. | Centralizar validación en `validateTitle` y detener `_save()` si el formulario no es válido. | Implementada en código; falta regresión en dispositivo |
| INC-002 | Media / P2 | Persistencia | Una actualización podría sobrescribir datos si el mapa del modelo no contiene los campos esperados. | Mantener un mapeo explícito en `Task.toMap()` y `Task.fromMap()`. | Mitigación incluida; validar en Firestore |
| INC-003 | Media / P2 | Experiencia de usuario | Un error de lectura podría dejar una pantalla sin explicación. | Mostrar estado de error en `StreamBuilder` y permitir reintento mediante nueva suscripción al reconstruir. | Manejo básico incluido; falta prueba de desconexión |

## Revisión paso a paso de la incidencia INC-001
1. **Reproducir:** abrir “Nueva tarea” e intentar guardar sin título.
2. **Leer:** revisar el formulario y el punto de llamada al repositorio.
3. **Hipótesis:** la escritura podría ejecutarse aunque el campo esté vacío.
4. **Comprobar:** el formulario debe ejecutar `validate()` antes de llamar al servicio.
5. **Corregir y proteger:** `if (!_formKey.currentState!.validate()) return;`; añadir prueba de widget que comprueba que no se invoca la escritura.

**Regresión:** ejecutar `flutter test test/widget/task_form_screen_test.dart` y repetir el caso en dispositivo. Registrar salida, fecha y captura real.
