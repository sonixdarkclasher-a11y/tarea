# 05. Reflexión sobre el proceso

**Estudiante:** Jonathan Josué Guzmán Alarcón  
**Carné:** 2927732022

Considero que una prueba integral que recorra el registro, la edición y la eliminación de una tarea en Firestore ayudaría a encontrar errores importantes antes de entregar la aplicación. Revisar únicamente la pantalla no garantiza que los datos se guarden correctamente ni que los permisos de la base estén configurados. También comprobé la importancia de validar la información antes de enviarla al servicio. Trabajar con un repositorio separado permite simular las operaciones al probar los widgets. Además, los mensajes de error orientan al usuario cuando algo falla. Por último, llevar un registro de incidencias y relacionarlo con los commits facilita comprobar qué se corrigió y qué falta validar.
