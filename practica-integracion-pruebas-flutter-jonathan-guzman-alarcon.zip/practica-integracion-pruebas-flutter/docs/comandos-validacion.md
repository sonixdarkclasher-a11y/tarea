# Comandos para completar la validación

```bash
git checkout -b semana16-integracion
flutter doctor -v
flutter pub get
flutter analyze
flutter test
flutter test test/unit/task_validation_test.dart
flutter test test/widget/task_form_screen_test.dart
```

Copie la salida real de la terminal a `docs/evidencias/pruebas-y-analisis/`. Si FlutterFire no está configurado, `flutter run` fallará en la inicialización Firebase: configure el proyecto antes de capturar el arranque exitoso.
