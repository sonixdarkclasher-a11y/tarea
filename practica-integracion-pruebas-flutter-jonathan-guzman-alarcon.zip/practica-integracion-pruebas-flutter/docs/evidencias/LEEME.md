# Evidencias

**Estudiante:** Jonathan Josué Guzmán Alarcón  
**Carné:** 2927732022

El archivo `capturas-aplicacion/referencia-interfaz.png` sirve como muestra del diseño. Para demostrar que la aplicación funciona, agregue imágenes tomadas directamente del emulador o del teléfono durante las pruebas:

- `capturas-aplicacion/`: lista, formulario, edición y eliminación.
- `firebase/`: colección `tasks` y documentos creados/actualizados/eliminados.
- `notificaciones-fcm/`: no aplica; FCM está fuera del alcance declarado.
- `pruebas-y-analisis/`: terminal con `flutter test` y `flutter analyze`.

La referencia visual no sustituye capturas de ejecución real ni demuestra por sí sola una conexión con Firebase.
