# Notificaciones FCM

**Estudiante:** Jonathan Josué Guzmán Alarcón  
**Carné:** 2927732022

En esta versión no se implementó Firebase Cloud Messaging. Como las notificaciones push no forman parte del alcance definido, los casos CP-14, CP-15, CP-16 y CP-17 quedan excluidos y no se reportan como ejecutados.
