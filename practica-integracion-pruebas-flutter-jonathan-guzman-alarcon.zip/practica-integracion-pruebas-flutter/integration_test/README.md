# Pruebas de integración

**Estudiante:** Jonathan Josué Guzmán Alarcón  
**Carné:** 2927732022

Para ejecutar una prueba completa es necesario configurar Firebase y utilizar un dispositivo o emulador. Este documento describe el recorrido sugerido, pero no realiza escrituras automáticas en una base de datos; así se evita modificar información real sin intención.

Flujo recomendado: iniciar app → crear tarea de prueba → verificar documento en `tasks` → editar → marcar completada → eliminar → verificar ausencia.
