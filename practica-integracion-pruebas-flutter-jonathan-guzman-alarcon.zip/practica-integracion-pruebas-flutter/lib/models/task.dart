class Task {
  const Task({
    required this.id,
    required this.title,
    required this.description,
    required this.isDone,
    required this.createdAt,
  });

  final String id;
  final String title;
  final String description;
  final bool isDone;
  final DateTime createdAt;

  Map<String, Object?> toMap() => {
        'title': title,
        'description': description,
        'isDone': isDone,
        'createdAt': createdAt.toIso8601String(),
      };

  factory Task.fromMap(String id, Map<String, dynamic> map) => Task(
        id: id,
        title: map['title'] as String? ?? '',
        description: map['description'] as String? ?? '',
        isDone: map['isDone'] as bool? ?? false,
        createdAt: DateTime.tryParse(map['createdAt'] as String? ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0),
      );
}
