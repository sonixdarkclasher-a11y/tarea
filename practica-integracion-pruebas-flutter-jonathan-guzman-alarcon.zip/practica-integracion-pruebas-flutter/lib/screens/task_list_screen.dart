import 'package:flutter/material.dart';
import '../models/task.dart';
import '../services/task_repository.dart';
import 'task_form_screen.dart';

class TaskListScreen extends StatelessWidget {
  const TaskListScreen({super.key, required this.repository});
  final TaskRepository repository;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mis tareas'),
        actions: [
          IconButton(
            tooltip: 'Información',
            icon: const Icon(Icons.info_outline),
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'Gestión de tareas',
              applicationVersion: '1.0.0',
              children: const [Text('Aplicación académica con Cloud Firestore.')],
            ),
          ),
        ],
      ),
      body: StreamBuilder<List<Task>>(
        stream: repository.watchTasks(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Center(
              child: Text('No se pudieron cargar las tareas. Intenta nuevamente.'),
            );
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final tasks = snapshot.data ?? [];
          if (tasks.isEmpty) {
            return const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.checklist, size: 64, color: Colors.blueGrey),
                  SizedBox(height: 12),
                  Text('No hay tareas todavía', style: TextStyle(fontSize: 18)),
                  Text('Presiona + para crear tu primera tarea'),
                ],
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: tasks.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final task = tasks[index];
              return Card(
                child: ListTile(
                  leading: Checkbox(
                    value: task.isDone,
                    onChanged: (value) => repository.updateTask(
                      Task(
                        id: task.id,
                        title: task.title,
                        description: task.description,
                        isDone: value ?? false,
                        createdAt: task.createdAt,
                      ),
                    ),
                  ),
                  title: Text(
                    task.title,
                    style: TextStyle(
                      decoration: task.isDone ? TextDecoration.lineThrough : null,
                    ),
                  ),
                  subtitle: task.description.isEmpty ? null : Text(task.description),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => TaskFormScreen(
                        repository: repository,
                        task: task,
                      ),
                    ),
                  ),
                  trailing: IconButton(
                    tooltip: 'Eliminar tarea',
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      await repository.deleteTask(task.id);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Tarea eliminada')),
                        );
                      }
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute<void>(
            builder: (_) => TaskFormScreen(repository: repository),
          ),
        ),
        icon: const Icon(Icons.add),
        label: const Text('Nueva tarea'),
      ),
    );
  }
}
