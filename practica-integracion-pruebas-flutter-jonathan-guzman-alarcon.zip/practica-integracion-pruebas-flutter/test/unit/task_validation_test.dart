import 'package:flutter_test/flutter_test.dart';
import 'package:practica_integracion_pruebas_flutter/utils/task_validator.dart';

void main() {
  group('validateTaskTitle', () {
    test('rechaza título vacío o con espacios', () {
      expect(validateTaskTitle('   '), 'Escribe un título');
      expect(validateTaskTitle(null), 'Escribe un título');
    });
    test('rechaza título menor de tres caracteres', () {
      expect(validateTaskTitle('ab'), 'Usa al menos 3 caracteres');
    });
    test('acepta título válido', () {
      expect(validateTaskTitle('Estudiar Flutter'), isNull);
    });
  });
}
