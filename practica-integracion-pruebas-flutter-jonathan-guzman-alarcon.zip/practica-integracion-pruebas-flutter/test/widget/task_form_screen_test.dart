import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:practica_integracion_pruebas_flutter/models/task.dart';
import 'package:practica_integracion_pruebas_flutter/screens/task_form_screen.dart';
import 'package:practica_integracion_pruebas_flutter/services/task_repository.dart';

class FakeTaskRepository implements TaskRepository {
  final List<Task> tasks = [];
  @override
  Stream<List<Task>> watchTasks() => Stream.value(tasks);
  @override
  Future<void> addTask({required String title, required String description}) async {
    tasks.add(Task(
      id: 'fake-1',
      title: title.trim(),
      description: description.trim(),
      isDone: false,
      createdAt: DateTime(2026, 1, 1),
    ));
  }
  @override
  Future<void> updateTask(Task task) async {
    final index = tasks.indexWhere((item) => item.id == task.id);
    if (index >= 0) tasks[index] = task;
  }
  @override
  Future<void> deleteTask(String id) async {
    tasks.removeWhere((item) => item.id == id);
  }
}

void main() {
  testWidgets('muestra validación si el título está vacío', (tester) async {
    final repository = FakeTaskRepository();
    await tester.pumpWidget(MaterialApp(
      home: TaskFormScreen(repository: repository),
    ));
    await tester.tap(find.text('Guardar tarea'));
    await tester.pump();
    expect(find.text('Escribe un título'), findsOneWidget);
    expect(repository.tasks, isEmpty);
  });

  testWidgets('guarda una tarea válida usando fake repository', (tester) async {
    final repository = FakeTaskRepository();
    await tester.pumpWidget(MaterialApp(
      home: TaskFormScreen(repository: repository),
    ));
    await tester.enterText(find.byType(TextFormField).first, 'Preparar informe');
    await tester.tap(find.text('Guardar tarea'));
    await tester.pumpAndSettle();
    expect(repository.tasks, hasLength(1));
    expect(repository.tasks.first.title, 'Preparar informe');
  });
}
